"""Run instrumented C++ structural searches without software search caps."""
from pathlib import Path
import ctypes as ct
import hashlib
import json
import os
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone

JOB = Path(__file__).resolve().parent
BUILD = json.loads((JOB / 'build.json').read_text())
REPO = Path(BUILD['repository'])
sys.path.insert(0, str(REPO))


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    os.replace(temporary, path)


def load_library():
    library = ct.CDLL(BUILD['library_path'])
    pointer = ct.POINTER(ct.c_uint64)
    library.synkit_crn_structural_sets.argtypes = [ct.c_size_t, ct.c_size_t, pointer, pointer, ct.c_double, ct.c_uint64, ct.c_size_t, ct.POINTER(ct.c_void_p)]
    library.synkit_crn_structural_sets.restype = ct.c_int
    library.synkit_crn_free_text.argtypes = [ct.c_void_p]
    library.synkit_crn_free_text.restype = None
    return library


def search(library, model, kind='siphon'):
    import numpy as np
    from synkit.CRN.Petrinet.net import PetriNet
    net = PetriNet.from_syncrn(model)
    places = net.place_order
    index = {place: i for i, place in enumerate(places)}
    words = (len(places) + 63) // 64
    pre = np.zeros((len(net.transition_order), words), dtype=np.uint64)
    post = pre.copy()
    for t, rid in enumerate(net.transition_order):
        for side, array in ((net.transitions[rid].pre, pre), (net.transitions[rid].post, post)):
            for place, weight in side.items():
                if weight > 0:
                    i = index[place]
                    array[t, i // 64] |= np.uint64(1 << (i % 64))
    trigger, required = (post, pre) if kind == 'siphon' else (pre, post)
    output = ct.c_void_p()
    pointer = ct.POINTER(ct.c_uint64)
    try:
        # Zero disables each limit in this explicitly instrumented trial build.
        code = library.synkit_crn_structural_sets(len(places), len(net.transition_order), trigger.ctypes.data_as(pointer), required.ctypes.data_as(pointer), 0.0, 0, 0, ct.byref(output))
        if code or not output.value:
            raise RuntimeError('Uncapped C++ search failed: ' + str(code))
        result = json.loads(ct.string_at(output).decode('ascii'))
    finally:
        if output.value:
            library.synkit_crn_free_text(output)
    result['sets'] = sorted(sorted(places[i] for i in group) for group in result['sets'])
    return net, result


def preflight():
    from Experiment.CRN.benchmarks.networks import BENCHMARK_NETWORKS
    from synkit.CRN import enumerate_structural_sets
    library = load_library()
    checks = []
    for fixture in BENCHMARK_NETWORKS:
        model = fixture.build()
        for kind in ('siphon', 'trap'):
            reference = enumerate_structural_sets(model, kind=kind, backend='cpp', library_path=BUILD['reference_library'])
            _, got = search(library, model, kind)
            assert reference.complete and got['termination_reason'] == 'complete', (fixture.name, kind)
            assert got['sets'] == reference.value['sets'], (fixture.name, kind)
            assert got['closure_evaluations'] == reference.value['closure_evaluations'], (fixture.name, kind)
            checks.append({'network': fixture.name, 'kind': kind, 'matches': True})
    write_json(JOB / 'preflight.json', {'status': 'PASS', 'n_checks': len(checks), 'checks': checks, 'limits': BUILD['limits']})
    print('Uncapped C++ preflight:', len(checks), 'matching completed reference searches', flush=True)


def worker(name):
    from Experiment.CRN.benchmarks.scaling import generate_network
    from Experiment.CRN.studies.biomodels import fetch
    from synkit.CRN import crn_from_sbml
    if name == 'random_sparse_50_seed0':
        model = generate_network('random_sparse', 50, seed=0)
    elif name == 'BIOMD0000000019':
        model = crn_from_sbml(fetch(name, offline=True))
    else:
        raise ValueError(name)
    library = load_library()
    started = time.monotonic()
    last_write = [0.0]
    state = {'network': name, 'pid': os.getpid(), 'status': 'RUNNING', 'complete': False, 'n_species': model.n_species, 'n_reactions': model.n_reactions, 'started_utc': utc(), 'limits': BUILD['limits'], 'closure_evaluations': 0, 'provisional_siphon_count': 0, 'frontier_size': 0, 'seen_states': 0, 'elapsed_seconds': 0.0}
    progress_path = JOB / (name + '.progress.json')
    write_json(progress_path, state)

    callback_type = ct.CFUNCTYPE(None, ct.c_uint64, ct.c_size_t, ct.c_size_t, ct.c_size_t)
    def progress(nodes, found, frontier, seen):
        now = time.monotonic()
        if now - last_write[0] < 5.0:
            return
        last_write[0] = now
        state.update(closure_evaluations=int(nodes), provisional_siphon_count=int(found), frontier_size=int(frontier), seen_states=int(seen), elapsed_seconds=now-started, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, updated_utc=utc())
        write_json(progress_path, state)
    callback = callback_type(progress)
    library.synkit_crn_set_progress.argtypes = [callback_type]
    library.synkit_crn_set_progress.restype = None
    library.synkit_crn_set_progress(callback)
    print(name, 'started with time, node and result caps disabled', flush=True)
    net, result = search(library, model)
    elapsed = time.monotonic() - started
    groups = result['sets']
    valid = all(group and all(not(set(t.post)&set(group)) or bool(set(t.pre)&set(group)) for t in net.transitions.values()) for group in groups)
    assert valid, 'Invalid returned siphon'
    complete = result['termination_reason'] == 'complete'
    report = {'schema': 'synkit.crn-uncapped-siphons/1', 'status': 'PASS' if complete else 'INCOMPLETE', 'network': name, 'complete': complete, 'elapsed_seconds': elapsed, 'finished_utc': utc(), 'limits': BUILD['limits'], 'n_species': model.n_species, 'n_reactions': model.n_reactions, 'complete_siphon_count': len(groups) if complete else None, 'returned_set_count': len(groups), 'all_returned_sets_valid': valid, 'build': BUILD, **result}
    write_json(JOB / (name + '.result.json'), report)
    state.update(status=report['status'], complete=complete, elapsed_seconds=elapsed, closure_evaluations=result['closure_evaluations'], provisional_siphon_count=len(groups), complete_siphon_count=report['complete_siphon_count'], termination_reason=result['termination_reason'], updated_utc=utc())
    write_json(progress_path, state)
    print(name, 'finished', report['status'], 'siphons', len(groups), 'elapsed', elapsed, flush=True)


def manager():
    processes = {}
    handles = []
    for name in BUILD['networks']:
        handle = (JOB / (name + '.log')).open('a', buffering=1)
        handles.append(handle)
        process = subprocess.Popen([sys.executable, str(Path(__file__)), 'worker', name], cwd=REPO, stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT)
        processes[name] = process
    write_json(JOB / 'pids.json', {'manager': os.getpid(), 'workers': {name: process.pid for name, process in processes.items()}})
    last_log = 0.0
    while True:
        rows = []
        for name, process in processes.items():
            path = JOB / (name + '.progress.json')
            row = json.loads(path.read_text()) if path.exists() else {'network': name, 'status': 'STARTING', 'complete': False}
            exit_code = process.poll()
            row['worker_alive'] = exit_code is None
            row['exit_code'] = exit_code
            if exit_code is not None and not (JOB / (name + '.result.json')).exists():
                row['status'] = 'FAILED'
            rows.append(row)
        running = any(row['worker_alive'] for row in rows)
        status = 'RUNNING' if running else ('PASS' if all(row.get('complete') for row in rows) else 'INCOMPLETE')
        write_json(JOB / 'summary.json', {'schema': 'synkit.crn-uncapped-siphons-run/1', 'status': status, 'limits': BUILD['limits'], 'updated_utc': utc(), 'measurements': rows})
        now = time.monotonic()
        if now - last_log >= 30 or not running:
            print(utc(), [(row['network'], row['status'], row.get('closure_evaluations'), row.get('provisional_siphon_count'), round(row.get('elapsed_seconds', 0), 1)) for row in rows], flush=True)
            last_log = now
        if not running:
            return
        time.sleep(5)


if __name__ == '__main__':
    {'preflight': preflight, 'manager': manager, 'worker': lambda: worker(sys.argv[2])}[sys.argv[1]]()
