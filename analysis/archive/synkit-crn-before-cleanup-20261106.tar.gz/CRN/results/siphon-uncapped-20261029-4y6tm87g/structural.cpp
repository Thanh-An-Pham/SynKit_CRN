// Full closure-guided minimal siphon/trap enumeration over arbitrary bitsets.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
using ProgressCallback = void (*)(std::uint64_t, std::size_t, std::size_t, std::size_t);
static ProgressCallback progress_callback = nullptr;
extern "C" void synkit_crn_set_progress(ProgressCallback callback) { progress_callback = callback; }
namespace {
using Mask = std::vector<std::uint64_t>;
using Clock = std::chrono::steady_clock;
struct Limit { const char* reason; };
struct Hash {
    std::size_t operator()(const Mask& mask) const {
        std::size_t h=0;
        for (auto w: mask) h ^= std::hash<std::uint64_t>{}(w)+0x9e3779b9+(h<<6)+(h>>2);
        return h;
    }
};
struct Search {
    std::size_t n, words, transitions;
    const std::uint64_t* trigger;
    const std::uint64_t* required;
    Clock::time_point deadline;
    void check() const { if (deadline != Clock::time_point::max() && Clock::now() >= deadline) throw Limit{"time_limit"}; }
    static bool nonempty(const Mask& mask) {
        return std::any_of(mask.begin(), mask.end(), [](std::uint64_t w){return w!=0;});
    }
    Mask closure(Mask current) const {
        bool changed=true;
        while (changed) {
            check(); changed=false;
            for (std::size_t t=0; t<transitions; ++t) {
                check();
                bool hit=false, satisfied=false;
                for (std::size_t w=0; w<words; ++w) {
                    hit |= bool(trigger[t*words+w] & current[w]);
                    satisfied |= bool(required[t*words+w] & current[w]);
                }
                if (hit && !satisfied) {
                    for (std::size_t w=0; w<words; ++w) current[w] &= ~trigger[t*words+w];
                    changed=true;
                }
            }
        }
        return current;
    }
};
}
extern "C" {
int synkit_crn_structural_abi() { return 1; }
int synkit_crn_structural_sets(std::size_t n, std::size_t transitions,
                              const std::uint64_t* trigger, const std::uint64_t* required,
                              double seconds, std::uint64_t max_nodes, std::size_t max_results,
                              char** output) {
    if (!output || !std::isfinite(seconds) || seconds < 0 || seconds > 1e9) return 2;
    *output=nullptr;
    Search search{n, (n+63)/64, transitions, trigger, required,
                  seconds == 0 ? Clock::time_point::max() : Clock::now()+std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(seconds))};
    std::vector<Mask> results;
    std::uint64_t nodes=0;
    std::size_t peak=0;
    const char* reason="complete";
    try {
        Mask allowed(search.words, ~std::uint64_t(0));
        if (n%64) allowed.back() = (std::uint64_t(1)<<(n%64))-1;
        Mask root=search.closure(std::move(allowed));
        std::vector<Mask> stack;
        std::unordered_set<Mask,Hash> seen;
        if (Search::nonempty(root)) { stack.push_back(root); seen.insert(root); }
        std::unordered_set<Mask,Hash> emitted;
        auto descend = [&](Mask candidate) {
            if (max_nodes && nodes>=max_nodes) throw Limit{"node_limit"};
            ++nodes;
            if (progress_callback && (nodes % 262144 == 0)) progress_callback(nodes, results.size(), stack.size(), seen.size());
            return search.closure(std::move(candidate));
        };
        while (!stack.empty()) {
            search.check();
            Mask current=std::move(stack.back()); stack.pop_back();
            Mask minimal=current;
            // Greedily shrink to a proven minimal closed set. Closure is
            // monotone, so a failed deletion stays failed after further shrinkage.
            for (std::size_t p=0; p<n; ++p) {
                if (!(minimal[p/64] & (std::uint64_t(1)<<(p%64)))) continue;
                Mask child=minimal;
                child[p/64] &= ~(std::uint64_t(1)<<(p%64));
                child=descend(std::move(child));
                if (Search::nonempty(child)) minimal=std::move(child);
            }
            if (emitted.insert(minimal).second) results.push_back(minimal);
            // Every OTHER minimal closed set omits at least one member of the
            // one just found. Branch only on those exclusions, not on every
            // species of the maximal closed set (which explores redundant unions).
            if (minimal != current) {
                for (std::size_t p=0; p<n; ++p) {
                    if (!(minimal[p/64] & (std::uint64_t(1)<<(p%64)))) continue;
                    Mask child=current;
                    child[p/64] &= ~(std::uint64_t(1)<<(p%64));
                    child=descend(std::move(child));
                    if (Search::nonempty(child) && seen.insert(child).second)
                        stack.push_back(std::move(child));
                    peak=std::max(peak, stack.size());
                }
            }
            if (max_results && results.size()>=max_results && !stack.empty()) throw Limit{"result_limit"};
        }
    } catch (const Limit& limit) { reason=limit.reason; }
      catch (const std::bad_alloc&) { reason="allocation_failure"; }
      catch (...) { return 2; }
    try {
        std::ostringstream out;
        out << "{\"termination_reason\":\"" << reason << "\",\"closure_evaluations\":" << nodes
            << ",\"peak_frontier\":" << peak << ",\"sets\":[";
        for (std::size_t r=0; r<results.size(); ++r) {
            if (r) out << ',';
            out << '['; bool first=true;
            for (std::size_t p=0; p<n; ++p) if (results[r][p/64] & (std::uint64_t(1)<<(p%64))) {
                if (!first) out << ',';
                first=false; out << p;
            }
            out << ']';
        }
        out << "]}";
        auto text=out.str();
        auto* buffer=static_cast<char*>(std::malloc(text.size()+1));
        if (!buffer) return 2;
        std::memcpy(buffer,text.c_str(),text.size()+1); *output=buffer;
        return 0;
    } catch (...) { return 2; }
}
}

extern "C" int synkit_crn_exhaustive_siphons(std::size_t n,std::size_t transitions,
 const std::uint64_t* pre,const std::uint64_t* post,double seconds,char** output){
 if(!output||n>24||!std::isfinite(seconds)||seconds<=0||seconds>1e9)return 2;
 *output=nullptr;auto deadline=Clock::now()+std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(seconds));
 std::vector<std::uint64_t> minimal;const char* reason="complete";std::uint64_t inspected=0;
 try{
  for(std::uint64_t mask=1;mask<(std::uint64_t(1)<<n);++mask){
   if(Clock::now()>=deadline)throw Limit{"time_limit"};++inspected;bool valid=true;
   for(std::size_t t=0;t<transitions;++t)if((post[t]&mask) && !(pre[t]&mask)){valid=false;break;}
   if(!valid)continue;bool dominated=false;for(auto m:minimal)if((m&mask)==m){dominated=true;break;}
   if(!dominated)minimal.push_back(mask);
  }
 }catch(const Limit& l){reason=l.reason;}catch(...){return 2;}
 std::ostringstream out;out<<"{\"termination_reason\":\""<<reason<<"\",\"subsets\":"<<inspected<<",\"sets\":[";
 for(std::size_t r=0;r<minimal.size();++r){if(r)out<<',';out<<'[';bool first=true;for(std::size_t i=0;i<n;++i)if(minimal[r]&(std::uint64_t(1)<<i)){if(!first)out<<',';first=false;out<<i;}out<<']';}out<<"]}";
 auto text=out.str();auto* buffer=static_cast<char*>(std::malloc(text.size()+1));if(!buffer)return 2;std::memcpy(buffer,text.c_str(),text.size()+1);*output=buffer;return 0;
}
